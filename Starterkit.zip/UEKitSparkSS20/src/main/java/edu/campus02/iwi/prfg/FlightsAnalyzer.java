package edu.campus02.iwi.prfg;

import static org.apache.spark.sql.functions.col;

import org.apache.spark.SparkConf;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.graphframes.GraphFrame;

import spark.exercise.env.WinConfig;

public class FlightsAnalyzer {

	public static void main(String[] args) {

		WinConfig.setupEnv();

		SparkConf cnf = new SparkConf().setMaster("local[2]")
				.set("spark.executor.memory", "2g")
				.set("spark.driver.memory", "2g")
				.setAppName(FlightsAnalyzer.class.getName());

		SparkSession spark = SparkSession.builder()
				.config(cnf)
				.getOrCreate();

		//a) airports DF
		Dataset<Row> airports = spark.read()
				.option("header",true)
				.option("delimiter",",")
				.option("nullValue", "\\N")
				.option("inferSchema",true)
				.csv("data/input/airports.dat")
				.cache();

		//b) airlines DF
		//TODO 1a: read in airlines DF

		//c) routes DF
		//TODO 1b: read in routes DF
		
		
		//TODO 2: create GraphFrame based on DataFrames
		
		//TODO 3:
		//all airports in "United Kingdom" or "Australia"
		//with at most 100 outgoing flight connections
		
		//TODO 4:
		//all direct flights starting from Norway to Italy

	}

}
