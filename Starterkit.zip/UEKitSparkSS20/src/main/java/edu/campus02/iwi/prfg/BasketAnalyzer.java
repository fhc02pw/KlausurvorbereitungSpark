package edu.campus02.iwi.prfg;

import static org.apache.spark.sql.functions.*;

import spark.exercise.env.WinConfig;

public class BasketAnalyzer {

	public static void main(String[] args) {

		WinConfig.setupEnv();
		
		//TODO 1 - 7 here...
		
	}
}